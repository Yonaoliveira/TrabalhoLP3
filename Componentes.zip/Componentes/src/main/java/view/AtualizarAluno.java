package view;

import javax.swing.*;

public class AtualizarAluno {
    private JPanel panel2;
    private JTextField textFieldNome;
    private JLabel jLabelNome;
    private JLabel jLabelSexo;
    private JLabel jLabelTelefone;
    private JTextField textFieldTelefone;
    private JButton atualizarButton;
    private JLabel jLabelEmail;
    private JTextField textFieldEmail;
    private JTextField textFieldIdentificador;
    private JLabel jLabelIdentificador;
    private JTextField textFieldSexo;
    private JLabel jLabelAtualizarAluno;
}
