package view;

import javax.swing.*;

public class AtualizarLivro {
    private JLabel jLabelTitle;
    private JLabel jLabelTema;
    private JLabel jLabelAutor;
    private JLabel jLabelIsbn;
    private JLabel jLablDataPub;
    private JLabel jLabelQuantidade;
    private JLabel jLabelIdentificador;
    private JTextField textFieldTitulo;
    private JTextField textFieldTema;
    private JTextField textFieldAutor;
    private JTextField textFieldIsbn;
    private JTextField textFieldDataPub;
    private JTextField textFieldQuantidade;
    private JTextField textFieldIdentifcador;
    private JLabel jLabelTitulo;
    private JButton atualizarButton;
}
