package view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Principal extends JFrame{
    private JMenuBar menuBar = new JMenuBar();
    private JPanel panel1 = new JPanel();

    public Principal() {
        criacaoDoMenu();
        this.setTitle(" sistema escola nova- cb");
        this.setContentPane(panel1);
        this.setSize(640, 480);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }

public void criacaoDoMenu(){
    this.setJMenuBar(menuBar);
    JMenu arquivo = new JMenu("Alunos");
    JMenuItem opcao1 = new JMenuItem("Cadastrar Aluno");
    JMenuItem opcao2 = new JMenuItem("Editar Aluno");
    JMenuItem opcao3 = new JMenuItem("Buscar Aluno");
    JMenuItem opcao4 = new JMenuItem("Remover Aluno");
    arquivo.add(opcao1);
    arquivo.add(opcao2);
    arquivo.add(opcao3);
    arquivo.add(opcao4);
    JMenu manterAluno = new JMenu("Livros");
    JMenuItem cadastro = new JMenuItem("Cadastrar Livro");
    JMenuItem editar = new JMenuItem("Editar Livro");
    JMenuItem buscar = new JMenuItem("Buscar Livro");
    JMenuItem remover = new JMenuItem("Remover Livro");
    manterAluno.add(cadastro);
    manterAluno.add(editar);
    manterAluno.add(buscar);
    manterAluno.add(remover);
    menuBar.add(arquivo);
    menuBar.add(manterAluno);

    opcao1.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new CadastrarAluno();
        }
    });

    opcao3.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new BuscarAluno();
        }
    });

    cadastro.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new CadastrarLivro();
        }
    });

    buscar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new BuscarLivro();
        }
    });

}

    }



